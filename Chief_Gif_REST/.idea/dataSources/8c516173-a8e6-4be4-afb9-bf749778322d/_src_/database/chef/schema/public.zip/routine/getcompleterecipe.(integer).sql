create function getcompleterecipe(id integer) returns TABLE(recipe_id numeric, recipe_name character varying, img_link character varying, user_name character varying, profile_picture character varying, likes integer, liked text)
LANGUAGE SQL
AS $$
SELECT
  r.recipe_id AS recipe_id,
  r.recipe_name :: VARCHAR,
  r.img_link,
  u.user_name :: VARCHAR,
  u.profile_picture,
  likes :: INT,
  liked
FROM "Recipe" r, "User" u, (SELECT count(*) AS likes
                            FROM users_likes
                            WHERE recipe_id = id) AS likes,
  (
    SELECT CASE WHEN likes = 0
      THEN 'NOT LIKED'
           ELSE 'LIKED' END AS "liked"
    FROM
      (
        SELECT count(*) AS likes
        FROM users_likes
        WHERE recipe_id = id AND user_id = id
      ) AS likes
  ) AS liked
WHERE r.recipe_id = id;
$$;
